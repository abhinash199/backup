function main(a, b = main()) {
    return a + b;
}
main();