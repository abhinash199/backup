$(document).ready(function() {
    
  $('#search').click(function() {
    window.location.href="/mycricket/schools/ambassador/register/1/school-list.html";
  });

  /*$('.fa.fa-search').on('click', function() {
    $('body').append("<div class=\"thinking-overlay\"><span class=\"fa fa-spinner fa-pulse\"></span></div>");
    $('body').addClass("body-block-scroll");
  });*/

  $('#update-submit-btn').on('click', function (event) {
    if($('#update-submit-btn').hasClass('disabled') == false) {
      $('#update-submit-btn').addClass('disabled');
      $('#update-submit-btn').append("<span class=\"fa fa-spinner fa-pulse\"></span>");
    }
  });

  $('#register-submit-btn').on('click', function (event) {
    if($('#register-submit-btn').hasClass('disabled') == false) {
      $('#register-submit-btn').addClass('disabled');
      $('#register-submit-btn').append("<span class=\"fa fa-spinner fa-pulse\"></span>");
    }
  });

  $('#test-btn').on('click', function (event) {
    event.preventDefault();
    $('.block-overlay').addClass('enabled');
    $('.block-overlay').addClass('full-screen');
    $('body').addClass('body-block-scroll');
    $('body').append("<div id=\"login-error\"><p class=\"title\">Oh no!</p><p>It seems that we have two email addresses on record for you. Which is correct?</p><div class=\"form-content-section\"><div class=\"form-group\"><div class=\"input-group radio\"><span class=\"input-group-addon\"><input id=\"email1\" type=\"radio\" name=\"email-group\" value=\"email1\"><label for=\"email1\">abc.def@gmail.com</label></span><span class=\"input-group-addon\"><input id=\"email2\" type=\"radio\" name=\"email-group\" value=\"email2\"><label for=\"email2\">ghi.jkl@gmail.com</label></span></div></div></div><a href=\"#\" id=\"login-error-btn\" class=\"light-green-btn\">Update my email</a></div>");
  });

  $('body').on('click', '#login-error-btn', function (event) {
    event.preventDefault();
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
    $('body').removeClass('body-block-scroll');
    $('#login-error').remove();
  });

  $('#gen-error-click').on('click', function (event) {
    event.preventDefault();
    if ($('#general-error').hasClass('hidden')) {
      $('.block-overlay').addClass('enabled');
      $('.block-overlay').addClass('full-screen');
      $('body').addClass('body-block-scroll');
      $('#general-error').removeClass('hidden');
    }
  });

  $('#close-btn').on('click', function (event) {
    event.preventDefault();
    $('#general-error').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });

  $('#gen-err-ok').on('click', function (event) {
    event.preventDefault();
    $('#general-error').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });

  $('#open-gigya-login').on('click', function (event) {
    event.preventDefault();
    $('#gigya-login').removeClass('hidden');
    $('.block-overlay').addClass('enabled');
    $('.block-overlay').addClass('full-screen');
    $('body').addClass('body-block-scroll');
  });

  $('#gigya-close').on('click', function (event) {
    event.preventDefault();
    $('#gigya-login').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });

  $('#open-gigya-register').on('click', function (event) {
    event.preventDefault();
    $('#gigya-login').addClass('hidden');
    $('#gigya-register').removeClass('hidden');
    $('.block-overlay').addClass('enabled');
    $('.block-overlay').addClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });

  $('#gigya-register-close').on('click', function (event) {
    event.preventDefault();
    $('#gigya-register').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
  });

  $('#gigya-social-popup').on('click', function (event) {
    event.preventDefault();
    $('#gigya-login').addClass('hidden');
    $('#gigya-social-linked').removeClass('hidden');
    $('.block-overlay').addClass('enabled');
    $('.block-overlay').addClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });

  $('#gigya-social-close').on('click', function (event) {
    event.preventDefault();
    $('#gigya-social-linked').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
  });

  $('#forgot-pwd-popup').on('click', function (event) {
    event.preventDefault();
    $('#gigya-login').addClass('hidden');
    $('#gigya-pwd-reset').removeClass('hidden');
    $('.block-overlay').addClass('enabled');
    $('.block-overlay').addClass('full-screen');
    $('body').addClass('body-block-scroll');
  });

  $('#gigya-pwd-close').on('click', function (event) {
    event.preventDefault();
    $('#gigya-pwd-reset').addClass('hidden');
    $('.block-overlay').removeClass('enabled');
    $('.block-overlay').removeClass('full-screen');
    $('body').removeClass('body-block-scroll');
  });
});

// Code for HTML5 Brightcove video player
var player = {},
    APIModules = {},
    experienceModule = [];

// Utility

function onTemplateLoad(experienceID) {
  player[experienceID] = brightcove.api.getExperience(experienceID);
  APIModules[experienceID] = brightcove.api.modules.APIModules;
}

function onTemplateReady(evt) {
  experienceModule.push(player[evt.target.experience.id].getModule(APIModules[evt.target.experience.id].EXPERIENCE));
  var evt = document.createEvent('UIEvents');
  evt.initUIEvent('resize', true, false, 0);
  window.dispatchEvent(evt);
}

window.onresize = function (evt) {
  $.each(experienceModule, function (key, item) {
    console.log(item);
    var resizeWidth = $("#" + item.experience.id).width();
    var resizeHeight = $("#" + item.experience.id).height();
    if (item.experience.type == "html") {
      item.setSize(resizeWidth, resizeHeight);
    }
  });
}
function closeWindow() {
    var win=window.open("about:blank","_self","");
    win.close();
}