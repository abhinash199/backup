$(document).ready(function() {

  //secondary-nav sub menu open and close
  var $subMenu = $('.has-tertiary');
  var $subMenuArrow = $subMenu.next('.fa');

  $subMenuArrow.on("click", function(e){
    e.preventDefault();
    var $subMenuItems = $(this).siblings('.tertiary');
    $subMenuItems.toggle('fast');
    $("ul.tertiary").not($subMenuItems).hide('fast');

    if($(this).hasClass("fa-angle-down")) {
      $(this).removeClass("fa-angle-down");
      $(this).addClass("fa-angle-up");
    }else{
      $(this).removeClass("fa-angle-up")
      $(this).addClass("fa-angle-down");
    }
  });

  var $current = $(".current.has-tertiary")
  var $currentMenu = $current.siblings('.tertiary');
  $currentMenu.css('display', 'block');
    
    $("#google-search-link").click(function () {
        $('#google-search-link').css('display', 'none');
        $('#google-search').css('background-color', '#fff');
        $('#google-search').css('width', '100%');
    });

        // if($('#loggedin-play').mouseenter(function(){
        //     $('#nav, #nav ul').css("height", "700px");
        //     $('.top-padding').css("padding-top", "50px");
        // }));
        //mouse enter from left to right of community - fadeUp to fadeDown
        // $("#community").mouseenter(function(e){
        //    var pWidth = $(this).innerWidth(); //use .outerWidth() if you want borders
        //    var pOffset = $(this).offset();
        //    var x = e.pageX - pOffset.left;
        //    if($("#community").mouseout(function(){
        //      console.log('mouseout community nav');
        //    }));
        //    if(pWidth/2 > x)
        //      $(".info-windows").removeClass('info-windows-up').addClass('info-windows-down');
        //    else
        //      $(".info-windows").removeClass('info-windows-down').addClass('info-windows-up');
        // });

        //open menu height depending on nav item
        if($('.Nav-item:has(#play)').mouseenter(function(){
            $('.play-content').fadeIn(1000).addClass('fade-in');
            /*$(".play-content").fadeIn("700", function() {
                console.log('123');
                $(this).addClass("fade-in");
            });*/
            $('.community-content').removeClass('fade-in');
        }));
        if($('.Nav-item:has(#community)').mouseenter(function(){
          $('.community-content').addClass('fade-in');
          $('.play-content').removeClass('fade-in');
        }));
        
        // dim background on hover
        $(function() {
            $('.Nav-item')
            .mouseenter(function() {
                $('.desktop-overlay').addClass('is-visible');
            })
            .mouseleave(function() {
                $('.desktop-overlay').removeClass('is-visible');
            });
        });

        //toggle header resize on scroll up/down
        $(function(){
            $('.mycricket-header').data('size','big');
          });

          $(window).scroll(function(){
            if($(document).scrollTop() > 0)
          {
              if($(window).width() >= 1024) {
                $('.mycricket-header').stop().animate({'top': '24px'},100);
                $('#nav li ul').stop().css({'top': '89px'});
                $('#nav li>a').css({'padding-bottom': '30px'});
                  if($('.mycricket-header').data('size') == 'big')
                  {
                      $('.mycricket-header').data('size','small');
                      $('.pc-logo').stop().css({
                          //'height':'85px',
                          'transform': 'scale(0.8)',
                          '-webkit-transform': 'scale(0.8)',
                          '-ms-transform': 'scale(0.8)',
                          '-moz-transform': 'scale(0.8)',
                          /*'width':'80px',*/
                          /*'margin-top': '15px'*/
                      });
                      $('.Nav-item.main-li > a').css({fontSize:'18px'});
                      $('#nav li>a').stop().css({'padding-bottom': '30px'});
                  }
                }
          }
          else
            {
              if($('.mycricket-header').data('size') == 'small')
                {
                  $('.mycricket-header').data('size','big');
                    //$('.mycricket-header').stop().animate({'top': '34px'},200);
                  $('.Nav-item.main-li > a').animate({fontSize:'21px'});
                  $('.pc-logo').stop().css({
                      //'height':'110px',
                      'transform': 'scale(1.0)',
                      '-webkit-transform': 'scale(1.0)',
                      '-ms-transform': 'scale(1.0)',
                      '-moz-transform': 'scale(1.0)',
                      /*'width':'100px',*/
                      /*'margin-top': '0px'*/
                  });
                 // $('.mycricket-header').stop().animate({'top': '34px'},200);
                }
                if($(window).width() >= 1024) {
                    $('.mycricket-header').stop().animate({'top': '38px'},100);
                    $('#nav li ul').css({'top': '102px'});
                    $('#nav li>a').css({'padding-bottom': '45px'});
                }
            }
        });
});
